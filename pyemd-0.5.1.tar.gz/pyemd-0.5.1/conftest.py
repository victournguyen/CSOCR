#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# conftest.py


collect_ignore = ["setup.py", "build", "dist"]
