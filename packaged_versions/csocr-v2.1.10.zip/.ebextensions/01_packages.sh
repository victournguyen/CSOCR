packages:
  yum:
    gcc-c++: []
    unixODBC-devel: []