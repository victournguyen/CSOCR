"""
Title: Comic Strip Optical Character Recognition
Authors: Victor Nguyen, Harry Liu

This program uses Dash and Materialize (CSS) to show a webpage where users can
upload one or more images that have text. The application will extract the text
from the images and display the images along with their extracted text.

Dash is a Python library created by Plotly which uses React.js and Plotly.js to
make a Flask application. Other libraries used include base64 and boto3.

The inputted image files are encoded in Base64, so we decode these and then use
Amazon's Textract to read the text.
"""
#-------------------------------Library Imports--------------------------------#
from dash import Dash, Input, Output, State, html, dcc
import base64
import boto3
# import random

#---------------------------------Application----------------------------------#
# Create Dash/Flask app with title
app = Dash(__name__)
title = 'Comic Strip Optical Character Recognition (CSOCR)'
app.title = title
# Server for deployment
application = app.server

# App layout
app.layout = html.Div(className='body', children=[
    html.Center(children=[
        # Title
        html.H3(id='title', children=title),
        # Multiple file upload
        dcc.Upload(id='upload', children=html.Div([
                'Drag and Drop or ',
                html.A('Select Files')
        ]), multiple=True),
        # Output that will hold the image, its caption, and the extracted text
        html.Div(id='output')
    ])
])

#----------------------------------Functions-----------------------------------#
def gen_text(text):
    """
    This function splits the given text by line and puts each line into a
    paragraph element. This makes the extracted text match the visualization
    better due to the newline characters not being displayed in one paragraph.
    Arguments:
        - text: string
            -- The cleaned text prepared for display
    """
    # Separate the text into lines
    lines = text.split('\n')
    texts = []
    for i in range(len(lines)):
        # Apply class names for formatting the margins in order to keep the
        # paragraph elements together while still keeping the spacing before and
        # after the group.
        cn = ''
        if i < len(lines) - 1:
            cn += ' card-text-top'
        if i > 0:
            cn += ' card-text-bottom'
        texts.append(html.P(className=cn.strip(), children=lines[i]))
    return texts

def gen(content, name):
    """
    This function extracts the text from the image and builds the HTML elements
    to display the image along with its text. It returns an HTML div with a row
    containing two columns, the image with a caption and the text seen by the
    program.
    Arguments:
        - content: string
            -- Base64-encoded image
        - name: string
            -- File name of the image
    """
    # Decode the Base64 string
    img = base64.b64decode(content[content.find('base64,') + len('base64,'):])

    # Create the Textract client
    textract = boto3.client(
        'textract',
        region_name='us-east-2',
        aws_access_key_id='AKIA5VXIP5O6CS7MK3MA',
        aws_secret_access_key='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',
    )
    # Detect the text using the bytes of the image
    response = textract.detect_document_text(Document={'Bytes': img})

    # Read the text by line
    text = ''
    for item in response["Blocks"]:
        if item["BlockType"] == "LINE":
            text += item["Text"] + '\n'
    text = text.strip()

    # Display for a single image and extracted text
    return html.Div(children=[
        html.Div(className='row', children=[
            html.Div(className='col s4 offset-s2', children=[
                # The image and its file name
                html.Figure(children=[
                    html.Img(src=content),
                    html.Figcaption(className='cap', children=name)
                ])
            ]),
            # Contains one paragraph element for each line
            html.Div(className='col s4 card-panel', children=gen_text(text))
        ])
    ])

@app.callback(
    Output('output', 'children'),
    Input('upload', 'contents'),
    State('upload', 'filename')
)
def upload(contents, names):
    """
    This function is the callback function for the file upload. It generates a
    list of displays for each image and its extracted text and returns it to the
    output container div.
    Arguments:
        - contents: list
            -- List of Base64-encoded images in the form of strings
        - names: list
            -- List of file names for the images
    """
    if contents is not None:
        # a = list(range(len(contents)))
        # random.shuffle(a)
        # contents = [contents[i] for i in a]
        # names = [names[i] for i in a]

        children = [gen(c, n) for c, n in zip(contents, names)]
        return children

#---------------------------------Program Run----------------------------------#
if __name__ == '__main__':
    # For running locally
    # app.run_server(port=8080, debug=True)
    # For deployment
    application.run(port=8080)